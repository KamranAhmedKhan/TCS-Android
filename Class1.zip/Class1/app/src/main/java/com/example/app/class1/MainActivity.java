package com.example.app.class1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //On design creation
        Log.i(TAG,"In OnCreate Event");
    }

    @Override
    protected void onStart() {
        super.onStart();
        //On Visible state
        Log.i(TAG,"In OnStart Event");
    }

    @Override
    protected void onResume() {
        super.onResume();
        //On Interactionable state
        Log.i(TAG,"In OnResume Event");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i(TAG,"In OnPause Event");
    }

    @Override
    protected void onStop() {
        super.onStop();

        Log.i(TAG,"In OnStop Event");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.i(TAG,"In OnDestroy Event");
    }

    public void secondActivity(View view) {
        Intent gotoSecondActivity = new Intent(MainActivity.this,SecondActivity.class);
        startActivity(gotoSecondActivity);
    }
}

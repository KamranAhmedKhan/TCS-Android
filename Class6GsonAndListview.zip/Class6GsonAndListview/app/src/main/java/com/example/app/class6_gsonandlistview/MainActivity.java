package com.example.app.class6_gsonandlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.app.class6_gsonandlistview.R;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    Gson gson;
//    ListView listview;
//    https://cdn0.iconfinder.com/data/icons/material-circle-apps/512/icon-android-material-design-512.png
    GridView listview;
    User[] users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gson = new Gson();
        textView = findViewById(R.id.textView);
        listview = findViewById(R.id.listview);

        String url = "http://dummy.restapiexample.com/api/v1/employees";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                users = gson.fromJson(response.toString(),User[].class);
//                textView.setText(response.toString());
//                ArrayAdapter<User> adapter = new ArrayAdapter<User>(MainActivity.this
//                        ,android.R.layout.simple_list_item_1,users);
                ListAdapter adapter = new ListAdapter(MainActivity.this,R.layout.list_item,users);
                listview.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                User user = users[position];
                Toast.makeText(MainActivity.this, user.name, Toast.LENGTH_SHORT).show();
            }
        });
//        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
//            @Override
//            public void onResponse(JSONArray response) {
//                textView.setText(response.toString());
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                textView.setText(error.getMessage());
//            }
//        });
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jsonArrayRequest);

//        String postUrl = "http://dummy.restapiexample.com/api/v1/create";
//        JSONObject jsonObject = new JSONObject();
////        {"name":"test","salary":"123","age":"23"}
//        try {
//            jsonObject.put("name","TestUser2");
//            jsonObject.put("salary","123");
//            jsonObject.put("age","22");
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, postUrl, jsonObject , new Response.Listener<JSONObject>() {
//            @Override
//            public void onResponse(JSONObject response) {
//                try {
//                    textView.setText("User with ID: "+response.getString("id")+
//                            " & Name: "+response.getString("name")
//                            +" created!");
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                textView.setText(error.getMessage());
//            }
//        });

//        queue.add(jsonObjectRequest);
    }
}

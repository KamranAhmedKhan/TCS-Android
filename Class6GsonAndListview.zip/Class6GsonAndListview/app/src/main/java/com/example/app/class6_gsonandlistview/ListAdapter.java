package com.example.app.class6_gsonandlistview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class ListAdapter extends ArrayAdapter<User> {

    int resource;
    public ListAdapter(@NonNull Context context, int resource,@NonNull User[] objects) {
        super(context, resource, objects);
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView==null)
            convertView = LayoutInflater.from(getContext()).inflate(resource,null,false);
        User user = getItem(position);
        ImageView imageview = convertView.findViewById(R.id.imageview);
        String imageUrl = "https://cdn0.iconfinder.com/data/icons/material-circle-apps/512/icon-android-material-design-512.png";
        Glide.with(getContext()).load(imageUrl).apply(new RequestOptions().placeholder(R.mipmap.ic_launcher).error(android.R.drawable.stat_notify_error)).into(imageview);
        TextView name = convertView.findViewById(R.id.name);
        TextView age = convertView.findViewById(R.id.age);
        name.setText(user.name);
        age.setText(user.age);
        return convertView;
    }
}

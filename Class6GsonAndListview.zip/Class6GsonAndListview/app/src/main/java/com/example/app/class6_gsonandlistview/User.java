package com.example.app.class6_gsonandlistview;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("employee_name")
    public String name;
    @SerializedName("employee_age")
    public String age;
    public String employee_salary;

    public String status;

    public User() {

    }

    public User(String name, String age, String salary) {
        this.name = name;
        this.age = age;
        this.employee_salary = salary;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                ", salary='" + employee_salary + '\'' +
                '}';
    }
}

package com.example.app.class5_volley;

public class User {
    public String name;
    public String age;
    public String salary;

    public User() {

    }

    public User(String name, String age, String salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }
}

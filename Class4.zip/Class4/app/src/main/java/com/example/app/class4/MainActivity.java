package com.example.app.class4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CheckBox aCheckbox,bCheckbox, cCheckbox;
    Button change;
    TextView textview;

    RadioGroup radioGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        aCheckbox = findViewById(R.id.aCheckbox);
        bCheckbox = findViewById(R.id.bCheckbox);
        cCheckbox = findViewById(R.id.cCheckbox);

        textview = findViewById(R.id.textview);

        change = findViewById(R.id.change);

        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (aCheckbox.isChecked()){
                    aCheckbox.setChecked(false);
                }else
                    aCheckbox.setChecked(true);

                textview.setText("Changed");
                change.setVisibility(View.GONE);
            }
        });

        bCheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    Toast.makeText(MainActivity.this, "Checked", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this, "Unchecked", Toast.LENGTH_SHORT).show();
                }
            }
        });


        radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId==R.id.male){
                    Toast.makeText(MainActivity.this, "Male Selected", Toast.LENGTH_SHORT).show();
                }else if (checkedId == R.id.female){
                    Toast.makeText(MainActivity.this, "Female Selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (savedInstanceState!=null && savedInstanceState.getString("text")!=null){
            String text = savedInstanceState.getString("text");
            textview.setText(text);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString("text",textview.getText().toString());
    }
}

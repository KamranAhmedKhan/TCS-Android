package com.example.app.class2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText number1, number2;
    Button calculate;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = findViewById(R.id.editText1);
        number2 = findViewById(R.id.editText2);

        calculate = findViewById(R.id.button);
        calculate.setOnClickListener(this);
        result = findViewById(R.id.result);
        result.setOnClickListener(this);

//        calculate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this,"Calculate button pressed!", Toast.LENGTH_LONG).show();
//            }
//        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button) {
//            Toast.makeText(MainActivity.this, "Calculate button pressed!", Toast.LENGTH_SHORT).show();
            int num1 = Integer.valueOf(number1.getText().toString());
            int num2 = Integer.valueOf(number2.getText().toString());

            result.setText("Result: "+(num1+num2));
        }else if (v.getId() == R.id.result){
            Toast.makeText(MainActivity.this, "Calculate button pressed!", Toast.LENGTH_LONG).show();
        }
    }

    public void SecondActivity(View view) {
        Intent intent = new Intent(MainActivity.this,SecondActivity.class);
        startActivity(intent);
    }

}

package com.example.app.class3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView textView;
    String data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        if (getIntent().hasExtra("data")){
            data = getIntent().getStringExtra("data");
        }

        textView = findViewById(R.id.textview);
        if (data!=null){
            textView.setText(data);
        }

        Intent intent = new Intent();
        intent.putExtra("data","This is data for First Activity");
        setResult(100,intent);
    }
}
